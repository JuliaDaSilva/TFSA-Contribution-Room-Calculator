package tfsa_contribution_room_calculator;

import java.util.Calendar;

public class ContributionCalculator {

    // Validates if the person is younger than 18 years old
    public boolean validateAge(int birthYear, int currentYear) {
        return currentYear - birthYear < 18;
    }

    // Validates if the birth year is valid
    public boolean validateBirth(int birthYear, int currentYear) {
        // Check if the birth year is more than 100 years in the past or in the future
        return (birthYear < (currentYear - 100) || birthYear > currentYear);
    }

    public int calculateTotalContributionRoom(int birthYear, double totalContributions,
            double totalWithdrawalsBefore2024, double totalWithdrawalsin2024) {

        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int yearTurned18 = birthYear + 18; // The year the user turned 18.
        int totalRoom = 0;

        // Calculates total contribution room from the year the user turned 18
        for (int year = yearTurned18; year <= currentYear; year++) {
            int annualLimit = getAnnualContributionLimit(year);
            totalRoom += annualLimit;
        }

        // Deducts the current year's contributions from the total room.
        totalRoom -= totalContributions;

        // Adds withdrawals made before the year 2024 to the total room.
        totalRoom += totalWithdrawalsBefore2024;

        // Subtracts withdrawals made in the year 2024 from the total room.
        totalRoom -= totalWithdrawalsin2024;

        return totalRoom;
    }

    public int getAnnualContributionLimit(int year) {
        if (year < 2009) {
            return 0; // Contribution room is 0 for years before 2009
        } else if (year < 2013) {
            return 5000; // Contribution limit for 2009 to 2012
        } else if (year < 2015) {
            return 5500; // Contribution limit for 2013 and 2014
        } else if (year == 2015) {
            return 10000; // Contribution limit for 2015
        } else if (year <= 2018) {
            return 5500; // Contribution limit for 2016 to 2018
        } else if (year <= 2022) {
            return 6000; // Contribution limit for 2019 to 2022
        } else if (year == 2023) {
            return 6500; // Contribution limit for 2023
        } else if (year >= 2024) {
            return 7000; // Contribution limit for 2024 and beyond
        }
        return 0; // Default return value if the year is out of range.
    }

}
