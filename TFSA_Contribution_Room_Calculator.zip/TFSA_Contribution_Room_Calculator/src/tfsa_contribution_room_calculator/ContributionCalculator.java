package tfsa_contribution_room_calculator;

import java.util.Calendar;

public class ContributionCalculator {

    // Validates if the person is younger than 18 years old
    public boolean validateAge(int birthYear, int currentYear) {
        return currentYear - birthYear < 18;
    }

    // Validates if the birth year is valid
    public boolean validateBirth(int birthYear, int currentYear) {
        return (birthYear < (currentYear - 100) || birthYear > currentYear);
    }

    /**
     * Calculates the total TFSA contribution room.
     *
     * @param birthYear User's birth year.
     * @param totalContributions Total contributions made to the TFSA.
     * @param totalWithdrawalsBefore2024 Total withdrawals from the TFSA before
     * the year 2024.
     * @param totalWithdrawalsin2024 Total withdrawals from the TFSA in the year
     * 2024.
     * @return Total contribution room available.
     */
    public double calculateTotalContributionRoom(int birthYear, double totalContributions,
            double totalWithdrawalsBefore2024, double totalWithdrawalsin2024) {

        // 
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        int yearTurned18 = birthYear + 18; // The year the user turned 18.
        double totalRoom = 0.0;

        // Calculates total contribution room from the year the user turned 18
        for (int year = yearTurned18; year <= currentYear; year++) {
            double annualLimit = getAnnualContributionLimit(year);
            totalRoom += annualLimit;
        }

        // Deducts the current year's contributions from the total room.
        totalRoom -= totalContributions;

        // Adds withdrawals made before the year 2024 to the total room.
        totalRoom += totalWithdrawalsBefore2024;

        // Subtracts withdrawals made in the year 2024 from the total room.
        totalRoom -= totalWithdrawalsin2024;

        return totalRoom;
    }

    /**
     * Calculates the annual contribution limit for a given year.
     *
     * @param year Year for required contribution limit to be calculated.
     * @return The annual contribution limit for the specified year.
     */
    public int getAnnualContributionLimit(int year) {
        // Contribution limits are defined based on the year.
        if (year < 2013) {
            return 5000;
        } else if (year < 2015) {
            return 5500;
        } else if (year == 2015) {
            return 10000;
        } else if (year <= 2018) {
            return 5500;
        } else if (year <= 2022) {
            return 6000;
        } else if (year == 2023) {
            return 6500;
        } else if (year >= 2024) {
            return 7000;
        }
        return 0; // Default return value if the year is out of range.
    }
}
